Changes to the SimMetrics library for .NET

In this release of the library the following changes have been made.

the support class from the Java conversion has been removed.
the tokeniser classes all use generics
new QGram classes have been added and a new base abstract class for QGram work also included
	we now have
		QGram 2 and 3 normal and extended
		SGram 2 and 3 and extended as well.
	
more unit tests

FxCop has been used to help isolate conflicts with C# standards


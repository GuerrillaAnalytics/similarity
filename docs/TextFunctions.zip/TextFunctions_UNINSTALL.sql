DROP FUNCTION Levenstein
DROP FUNCTION NeedlemanWunch
DROP FUNCTION SmithWaterman
DROP FUNCTION SmithWatermanGotoh
DROP FUNCTION SmithWatermanGotohWindowedAffine
DROP FUNCTION Jaro
DROP FUNCTION JaroWinkler
DROP FUNCTION ChapmanLengthDeviation
DROP FUNCTION ChapmanMeanLength
DROP FUNCTION QGramsDistance
DROP FUNCTION BlockDistance
DROP FUNCTION CosineSimilarity
DROP FUNCTION DiceSimilarity
DROP FUNCTION EuclideanDistance
DROP FUNCTION JaccardSimilarity
DROP FUNCTION MatchingCoefficient
DROP FUNCTION MongeElkan
DROP FUNCTION OverlapCoefficient
GO

IF  EXISTS (SELECT * FROM sys.assemblies asms WHERE asms.name = N'TextFunctions' and is_user_defined = 1)
DROP ASSEMBLY [TextFunctions]
GO

IF  EXISTS (SELECT * FROM sys.assemblies asms WHERE asms.name = N'SimMetrics' and is_user_defined = 1)
DROP ASSEMBLY [SimMetrics]
GO


